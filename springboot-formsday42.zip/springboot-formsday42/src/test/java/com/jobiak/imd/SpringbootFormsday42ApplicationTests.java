package com.jobiak.imd;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootFormsday42ApplicationTests {

	@Test
	void contextLoads() {
	}

}
