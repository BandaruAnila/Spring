create table emp(
empno integer not null auto_increment,
ename varchar(45) not null,
sal double,
deptno integer,
primary key(empno));