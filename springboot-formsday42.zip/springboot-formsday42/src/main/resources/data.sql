insert into emp(ename,sal,deptno)values('KING',5000,10);
insert into emp(ename,sal,deptno)values('James',2000,20);
insert into emp(ename,sal,deptno)values('Ward',2500,10);
insert into emp(ename,sal,deptno)values('Smith',8000,12);
insert into emp(ename,sal,deptno)values('Jane',9000,22);
insert into emp(ename,sal,deptno)values('Martin',4500,20);
insert into emp(ename,sal,deptno)values('Blake',3500,30);